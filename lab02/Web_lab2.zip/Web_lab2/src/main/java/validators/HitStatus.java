package validators;

public enum HitStatus {
    HIT,
    MISS,
    NOT_VALIDATED
}
