package servlets;

import beans.Point;
import beans.PointsArray;
import com.google.gson.Gson;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import validators.HitStatus;
import validators.Validator;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Servlet обработки запросов c координатами
 */
@WebServlet("/area-check-servlet")
public class AreaCheckServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            //Засекаем время начала
            long timer = System.nanoTime();

            //Валидируем запрос и получаем точку
            Validator validator = new Validator(req);
            HitStatus hitStatus = validator.getStatus();
            Point point = validator.getPoint();

            if(hitStatus.equals(HitStatus.NOT_VALIDATED)) return;

            //Форматируем время под часовой пояс клиента
            int timezone = Integer.parseInt(req.getParameter("timezone"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            String currentTime = formatter.format(LocalDateTime.now(ZoneOffset.UTC).plusMinutes(timezone));

            // Берем из контекста приложения список точек
            var context = getServletContext();
            if (context.getAttribute("dots") == null) {
                context.setAttribute("dots", new PointsArray());
            }
            PointsArray bean = (PointsArray) context.getAttribute("dots");

            // Указываем время запроса, статус, время работы скрипта и добавляем точку в массив
            point.setTime(currentTime);
            point.setStatus(hitStatus == HitStatus.HIT);
            long scriptTime = (long) ((System.nanoTime() - timer) * 0.001);
            point.setScriptTime(scriptTime);
            bean.addPoint(point);

            // Обновляем значение контекста приложения
            context.setAttribute("dots", bean);

            // Отправляем ответ с точкой
            Gson gson = new Gson();
            Map<String, Object> json = new HashMap<>();
            json.put("x", point.getX());
            json.put("y", point.getY());
            json.put("r", point.getR());
            json.put("status", point.getStatus());
            json.put("time", point.getTime());
            json.put("scriptTime", point.getScriptTime());
            String msg = gson.toJson(json);
            resp.getWriter().write(msg);
            resp.getWriter().flush();
        } catch (Exception exception){
            exception.printStackTrace();
            ControllerServlet.sendError(resp, "Data is incorrect");
        }
    }
}
