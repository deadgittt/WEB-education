// Скрипт, который срабатывает один раз после загрузки страницы.
// Создаём глобальный валидатор, в котором так же содержатся последние нажатые X и R.

const validator = new Validator();
window.onload = function () {
    // Рисуем пустой график
    const canvasPrinter = new CanvasPrinter();
    canvasPrinter.drawStartImage()
    // Для каждого чекбокса устанавливаем слушатель, который будет обновлять значение валидатора, и убирать галки с остальных чекбоксов
    const checkboxes = document.querySelectorAll('input[type=checkbox]')
    checkboxes.forEach((checkbox) => {
        checkbox.addEventListener("click", () => {
            validator.lastClickedX = checkbox.value;
            checkboxes.forEach((c) => {
                if (c !== checkbox) {
                    c.checked = false;
                }
            });
        });
    });

    // Устаналиваем слушатель на ввод Y
    document.querySelector("input[type=text]")
        .addEventListener("focusout", validator.validateY);

    // Устаналиваем слушатель на ввод R, который будет обновлять значение R в валидаторе и обновлять график
    document.querySelectorAll('input[name="R-radio-group"]').forEach(radio => {
        radio.addEventListener('click', () => {
            validator.lastClickedR = radio.value;
            canvasPrinter.redrawAll(radio.value)
        })
    })

    // Обработчик кликов по графику
    canvasPrinter.canvas.addEventListener('click', function(event) {
        canvasPrinter.parseClick(event)
    });
    // Not auto update page after form submit
    $('form').submit(function(e) {
        e.preventDefault();
    })
}