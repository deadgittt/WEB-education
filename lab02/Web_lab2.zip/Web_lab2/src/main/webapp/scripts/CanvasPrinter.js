// Класс отвечающий за отрисовку графика
class CanvasPrinter{
    SIZE = 300; // Ширина
    LINE_WIDTH = 2;
    TEXT_SIZE = 20;
    TEXT_MARGIN = 15;
    TEXT_LINE_HEIGHT = 3;
    COLOR_RED = "#b50300"
    COLOR_GREEN = "#00b509"
    COLOR_MAIN = "#00ADB5"
    TOTAL_POINTS = 10 // Разрешение в точках по X и Y (от -5 до 3 плюс одна точка по сторонам для паддинга)
    constructor() {
        this.canvas = document.getElementById("graph");
        this.ctx = this.canvas.getContext("2d");
        this.ctx.font = `${this.TEXT_SIZE}px VCR`
    }

    // Рисуем начальную картинку без радиуса (и графика)
    drawStartImage(){
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.drawAxes();
        this.setPointerAtDot(3);
        this.setPointerAtDot(1);
    }

    // Перерисовываем картинку с новым значением радиуса
    redrawAll(r){
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.drawGraph(r);
        this.drawAxes();
        this.setPointerAtDot(3);
        this.setPointerAtDot(1);
        this.drawPoints();
    }

    // Рисуем оси
    drawAxes() {
        this.ctx.fillStyle = "black";
        this.drawArrow(-this.SIZE, this.SIZE / 2, this.SIZE, this.SIZE / 2);
        this.drawArrow( this.SIZE / 2, this.SIZE, this.SIZE / 2, 0);
    }

    // Рисуем основной график
    drawGraph(r){
        // Высчитываем соотношение координаты и координаты на графике
        const pointInPixels = this.SIZE / this.TOTAL_POINTS;
        this.ctx.fillStyle = this.COLOR_MAIN;

        // Прямоугольник
        this.ctx.rect(this.SIZE / 2, this.SIZE / 2, r / 2 * pointInPixels, r * pointInPixels);
        this.ctx.fill()

        // Треугольник
        this.ctx.beginPath();
        this.ctx.moveTo(this.SIZE / 2, this.SIZE / 2);
        this.ctx.lineTo(this.SIZE / 2, this.SIZE / 2 + r * pointInPixels);
        this.ctx.lineTo(this.SIZE / 2 - (r / 2) * pointInPixels, this.SIZE / 2);
        this.ctx.lineTo(this.SIZE / 2, this.SIZE / 2);
        this.ctx.fill();

        // Окружность
        this.ctx.beginPath();
        this.ctx.arc(
            this.SIZE / 2,
            this.SIZE / 2,
            r / 2 * pointInPixels,
             Math.PI,
            3/2 * Math.PI
        );
        this.ctx.moveTo(this.SIZE / 2, this.SIZE / 2);
        this.ctx.lineTo(this.SIZE / 2, this.SIZE / 2 - r / 2 * pointInPixels);
        this.ctx.lineTo(this.SIZE / 2 - r / 2 * pointInPixels, this.SIZE / 2);
        this.ctx.lineTo(this.SIZE / 2, this.SIZE / 2);
        this.ctx.fill();
    }

    // Поставить цифру размерности на оси
    setPointerAtDot(max_r = 5) {
        const pointInPixels = this.SIZE / this.TOTAL_POINTS;
        this.ctx.textAlign = "center";
        this.ctx.textBaseline = "middle";
        this.ctx.fillText(`${max_r}`, this.SIZE / 2 + pointInPixels * max_r, this.SIZE / 2 - this.TEXT_MARGIN);
        this.ctx.fillText(`${max_r}`, this.SIZE / 2 + this.TEXT_MARGIN, this.SIZE / 2 - pointInPixels * max_r);

        this.ctx.beginPath()
        this.ctx.lineWidth = this.LINE_WIDTH;
        this.ctx.moveTo(this.SIZE / 2 + pointInPixels * max_r, this.SIZE / 2 + this.TEXT_LINE_HEIGHT);
        this.ctx.lineTo(this.SIZE / 2 + pointInPixels * max_r, this.SIZE / 2 - this.TEXT_LINE_HEIGHT);
        this.ctx.moveTo(this.SIZE / 2 + this.TEXT_LINE_HEIGHT, this.SIZE / 2 - pointInPixels * max_r);
        this.ctx.lineTo(this.SIZE / 2 - this.TEXT_LINE_HEIGHT, this.SIZE / 2 - pointInPixels * max_r);
        this.ctx.stroke();
    }

    // Нарисовать стрелку (взято с https://stackoverflow.com/questions/808826/draw-arrow-on-canvas-tag)
    drawArrow(fromx, fromy, tox, toy) {
        var headlen = 10; // length of head in pixels
        var dx = tox - fromx;
        var dy = toy - fromy;
        var angle = Math.atan2(dy, dx);
        this.ctx.beginPath();
        this.ctx.lineWidth = this.LINE_WIDTH;
        this.ctx.moveTo(fromx, fromy);
        this.ctx.lineTo(tox, toy);
        this.ctx.lineTo(tox - headlen * Math.cos(angle - Math.PI / 6), toy - headlen * Math.sin(angle - Math.PI / 6));
        this.ctx.moveTo(tox, toy);
        this.ctx.lineTo(tox - headlen * Math.cos(angle + Math.PI / 6), toy - headlen * Math.sin(angle + Math.PI / 6));
        this.ctx.stroke();
    }

    // Клик по графику
    parseClick(event){
        // Высчитываем координату
        const xPixels = event.clientX - this.canvas.getBoundingClientRect().left;
        const yPixels = event.clientY - this.canvas.getBoundingClientRect().top;
        const pointInPixels = this.SIZE / this.TOTAL_POINTS;
        const x = - (this.SIZE / 2 - xPixels) / pointInPixels
        const y = (this.SIZE / 2 - yPixels) / pointInPixels

        // Если клик вне зоны графика, то отображаем предупреждение
        if(x > 2 || x < -2 || y > 3 || y < -5) {
            Swal.fire({
                title: 'Клик вне зоны графика',
                text: 'X принимает значения от -2 до 2\n Y от -5 до 3',
                icon: 'warning'
            });
            return
        }

        // Если радиус не введен, то отображаем предупреждение
        if(!validator.lastClickedR) {
            Swal.fire({
                title: 'Невозможно определить радиус',
                text: 'Выберите радиус',
                icon: 'warning'
            });
            return
        }
        // Отправляем точку и обновляем страницу
        sendPoint(x.toFixed(3), y.toFixed(3), validator.lastClickedR)
        location.reload()
    }

    //Рисуем точки на графике
    drawPoints(){
        var arrData=[];
        // С помощью jquery парсим таблицу
        $("#results tr").each(function(){
            let currentRow=$(this);
            arrData.push({
                "x": parseFloat(currentRow.find("td:eq(0)").text()),
                "y": parseFloat(currentRow.find("td:eq(1)").text()),
                "r": parseFloat(currentRow.find("td:eq(2)").text()),
                "status": currentRow.find("td:eq(3)").text() === "Попадание",
                "time": currentRow.find("td:eq(4)").text(),
                "scriptTime": currentRow.find("td:eq(5)").text()
            })
        });
        arrData.shift() // Delete headers
        arrData.forEach(dot =>{
            this.drawPoint(dot.x, dot.y, dot.r, dot.status)
        })
    }

    //Рисуем одну точку на графике
    drawPoint(x, y, r, success = true) {
        // Расчитываем изменение координаты как отношение ее радиуса и текущего
        let r_now = validator.lastClickedR
        if(r_now != null) {
            x *= r_now / r
            y *= r_now / r
        }

        this.ctx.fillStyle = success
            ? this.COLOR_GREEN
            : this.COLOR_RED;
        const pointInPixels = this.SIZE / this.TOTAL_POINTS;
        this.ctx.beginPath();
        //Сама точка
        this.ctx.arc(
            this.SIZE / 2 + pointInPixels * x,
            this.SIZE / 2 - y * pointInPixels,
            5,
            0,
            Math.PI * 2,
        );
        this.ctx.fill();
        this.ctx.beginPath();
        this.ctx.fillStyle = "black"
        this.ctx.lineWidth = 1.5
        //Контур точки
        this.ctx.arc(
            this.SIZE / 2 + pointInPixels * x,
            this.SIZE / 2 - y * pointInPixels,
            5,
            0,
            Math.PI * 2
        )
        this.ctx.stroke();
    }
}